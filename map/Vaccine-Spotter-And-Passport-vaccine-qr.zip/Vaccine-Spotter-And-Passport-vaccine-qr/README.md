# Vaccine-Spotter-And-Passport
This project is initially being made for Jamhacks V, which is Waterloo’s largest high school hackathon. JAMHacks V takes place from May 22nd to 23rd. This year, 200+ students from high schools all over North America spend a full 24 hours of learning and creating!

Team: Michael Kougang @royalweden, Yair Korokhov @yair-k, David Zheng @davidzhengyes, and Katelyn Shah @katelynshah
